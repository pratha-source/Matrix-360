# 60-second demo
1. Open the page. "An n8n agent finds brokers weekly and writes them to a sheet" (see the discovery card).
2. Click Qualify all leads with AI, allow Claude. "The AI scores each lead out of 100 and decides if it qualifies."
3. Click a lead. "Every score comes with reasons from the evidence; unknowns are flagged as missing, not guessed."
4. Upload a real sheet or paste listings, then Download CSV.
Say plainly: discovery and the n8n qualifier are built but not yet deployed. Sample leads are made up. Nothing is sent to leads.
