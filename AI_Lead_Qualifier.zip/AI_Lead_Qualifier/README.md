# AI Lead Qualifier (prototype handoff)

An AI system that finds real-estate broker leads, scores each one out of 100 against a rubric,
decides Qualified or Not qualified, and explains why. No manual approval step. Nothing is sent to leads.

## Folder contents
| Path | What it is |
|---|---|
| `qualifier_page/ai_lead_qualifier.html` | Demo page. Upload a sheet or paste listings, AI scores each lead, shows reasoning, exports CSV. Published on claude.ai; this is the source. |
| `n8n_workflows/1_Lead_Discovery_Workflow.n8n.json` | Finds leads weekly via Google Places API (8 Hooghly towns), removes closed and duplicate businesses, appends to the sheet. |
| `n8n_workflows/2_AI_Lead_Qualifier_Workflow.n8n.json` | Scores up to 50 unscored rows per run using an AI API and writes verdict, score, reasoning back to the sheet. |
| `sheet_template/leads_sheet_template.csv` | Header row for the Google Sheet both workflows use. |
| `docs/demo_script.md` | 60-second demo script. |

## How it fits together
Monday: workflow 1 finds leads -> Google Sheet. Tuesday: workflow 2 scores new rows -> same sheet.
The demo page does the same qualifying on any uploaded sheet, for demos and checks.

## Rubric (100 points)
Location fit 25, sales activity 30, credibility 25, completeness 20. Qualified = 65 or more (a choice; tune it).
Completeness is computed by code (4 points per filled field of 5). The AI scores the other three using only the evidence given;
anything not stated is listed as missing, never guessed. Code clamps scores to the limits.

## Setup (about 30 minutes)
1. Create a Google Sheet. Paste the headers from `sheet_template/leads_sheet_template.csv` into row 1. Name the tab `Sheet1`.
2. Google Cloud: enable **Places API (New)**, create an API key, restrict it to that API.
3. Import both workflows into n8n. In each, set the Sheet ID and connect Google Sheets.
4. Workflow 1: paste the Google API key in the **Google Places Search** node. Edit towns in **Build Searches**.
5. Workflow 2: paste an Anthropic API key in the **Ask AI** node (header x-api-key). Confirm the model name `claude-sonnet-5-5`
   against Anthropic's current model list. Edit `TARGET_AREA` in **Pick Unqualified**.
6. Run each workflow manually on a few rows and check results before enabling the schedules. Both are saved switched off.

## Status: what is tested and what is not
- Demo page: opens pre-filled with 5 made-up sample leads; button flows tested in a headless browser with rule-based scoring and a simulated AI.
  NOT tested in a real browser: live AI scoring, Excel upload, CSV download. Run through it once before presenting.
- Workflow 2 code steps (pick, check and score) tested locally with fake data, including an unreadable AI reply.
- Neither n8n workflow has been run in n8n. Expect small fixes on first run (node versions, credential selection).
- The sample leads in the page are made up, not real businesses.

## Known limits and next steps
- Evidence from Google Places is limited (rating, reviews, address, website). RERA number, years active and listing counts
  are not available from it. Add an enrichment step (read the broker's site or listings) with source URLs and checks against invented facts.
- The page cannot browse the web, so discovery lives only in n8n.
- Check Google Places terms (what you may store, for how long) and current pricing before running on a schedule.
- Personal data: if phone numbers or emails are added, India's data protection law applies. Decide what to keep and for how long.
- Outreach is deliberately not automated: calls and SMS fall under TRAI and DND rules. A person should send first messages.
- Not built yet: pushing qualified leads to a CRM or Slack, a weekly summary report, a feedback loop from human review to the rubric.
- Suggested pilot: one area, about 100 leads, compare AI verdicts with a person's, tune the rubric and the 65 cut-off, then widen.

## Security
Never commit API keys. The workflow files contain placeholders (PASTE_YOUR_...). Put real keys in n8n credentials or environment variables.
Set spending caps on the Google and AI accounts.
